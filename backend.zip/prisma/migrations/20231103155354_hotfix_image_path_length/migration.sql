-- AlterTable
ALTER TABLE `User` MODIFY `cover` VARCHAR(255) NULL,
    MODIFY `avatar` VARCHAR(255) NULL;
