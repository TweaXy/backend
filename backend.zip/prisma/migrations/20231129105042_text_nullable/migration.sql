

-- AlterTable
ALTER TABLE `Interactions`
    MODIFY `text` VARCHAR(191) NULL;
