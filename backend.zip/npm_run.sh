#!/bin/bash
nginx
npm run start
