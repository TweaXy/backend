export default {
    type: 'service_account',
    project_id: 'push-nofitication-test-f51f4',
    private_key_id: '8816eda4c09f9de8c9bf941cd5f069e853bff7e3',
    private_key:
        '-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDB/sssIrmRDA+x\nF/JbDbkQKudoSsMk+yxVk60d+3BFLste0D08LJyTkJqCTk2w0E1NNvVLIjyVIFCF\nsEPgfb52avDVm+wlYCEcGms2NVoe0wI/WSLH4DVH4KSjDMd8cK/LizhQkkEYe5n9\nvX3F1TFRpD6NViMJyvfjapXYVI2GG2IJb2+w61uwqa/9e9rJas23j3WqjbvAx/Fj\nAYont1rmgvNMG1ATxhZnzD9zufHva2Y2+qDolWmoq9jN2PILJNm6Sqpo+ZIhik69\nvQqN1Oxj4UlOzFEscvFBT6Rrr80eVFx+W1Ssl/FRsFYhP0hsZ1Il0Q7CRrHJYBSi\n2VrJfKkJAgMBAAECggEAD6CjGB4Zmfna9cAt5NasXTh0X2FoBDDVRHUnnmFLJp37\naHR/MLuQE9vm2a8z8Pw59FaeC5YDEI+Dpqr2MApqvAb0LOQ2CyWJ5UXd8+yRiVqK\nm5tmaUWPGG6cGwpqs4QvlS0IHCCvOVxG1NSQyJp0Mgh4hYUDDSuAxpz0Dz/YdFoL\n8KnU71ByfHKhoLSDOw9Xbo5/bTBP9DHjiFr46XkskSBoZ6dT5ZeUqRj3UXVyWfxx\nAaz0v7EXyTs1aOKW3AqdvtWUlbMtSfzm0rw8RZpgJ0FEszkPZRPBKvhZwC70mjoO\nbNmW4puwLysCO1sgmhTGtNdnGvjGX5sqroKzk14kJQKBgQDxPB37r1CXuPzSxplD\nYiMEYLVa4kLE23xMO6T9iBOSpiPsO+/yoQUj4Q9tBY0D7opgtzTPi/A6bQGrvHjr\nlfeQCmC1qgW6/p1l9DMf18DStd/CRX3qhcH3lk8znh/Q4+5BvfC0+UQAKnnXY+UE\nIlEwgVarF4ZhDJ4ewfVOtAkqCwKBgQDN3nwxULPxEZA7U9ss7fzsMHrovu/pemHC\nn8ILys09UlpHYzKmk1rX8KsX2RQ858Vh4JSoOGlGlvZwj9kC6B/dyLIw8pi6P2FJ\nIEj/Yrsh34N5YIXfgvTUmwhviSWoAswE3hx9VyEuwyYEn41qmydYmcGkxXmoayQ/\nBIDBENu5uwKBgAJQtmT1AMwD/YE0YMIxze4702HE7CkhhibhJ6s7RBzTNWMODDaC\n7x6yCUjdlcXk4zUcbQhU6oBVDYANdgekz9R1FQqJUDbEPNR+rILwuiwLjNM7gYLf\nt8XdjnMLYHjLxzygSxAhmFJ8FeFIVylb/vV9OEy6FBMYYOggqm8P8UqTAoGAV8Ee\n72aXTYtPD/sO0ngf+A4yVkQNwFiKk4vGC4DHO/x+vy9px9fIQYQ1alT+a3fgi3hP\n5eUl+xEeu5yVxMdtzfxe+L5wm/OoZKN+el57plTAllyutDf+ZSIw1lp/0r5eeTS0\nsDkTy/sjmZTpkyfP/dSM1s/WrBP/v10MBUBKaUECgYEAhP849qpzlZ9CrGcBqMYd\n/2yeA6kp8jfqF+/9W4ih8pXl+eb4WyyT6/+9JaM1Qfd/rgRcAmta1RglJwSxwguK\ntTMVKHr+LMcTl8kTSMp+7Ev20JD4l6KTDRjndHJ8/9HpbdjLcn5XYs3VHVpzPQ2A\nT2sQ+EC4ZTCZxtpDSnaeFa8=\n-----END PRIVATE KEY-----\n',
    client_email:
        'firebase-adminsdk-k1aji@push-nofitication-test-f51f4.iam.gserviceaccount.com',
    client_id: '112697905404809007264',
    auth_uri: 'https://accounts.google.com/o/oauth2/auth',
    token_uri: 'https://oauth2.googleapis.com/token',
    auth_provider_x509_cert_url: 'https://www.googleapis.com/oauth2/v1/certs',
    client_x509_cert_url:
        'https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-k1aji%40push-nofitication-test-f51f4.iam.gserviceaccount.com',
    universe_domain: 'googleapis.com',
};

// cool should be removed
