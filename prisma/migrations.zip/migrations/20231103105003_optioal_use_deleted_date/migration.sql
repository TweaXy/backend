-- AlterTable
ALTER TABLE `User` MODIFY `deletedDate` DATETIME(3) NULL;
