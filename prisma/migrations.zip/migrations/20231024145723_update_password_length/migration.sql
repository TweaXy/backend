-- AlterTable
ALTER TABLE `User` MODIFY `password` VARCHAR(65) NOT NULL;
