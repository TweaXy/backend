-- AlterTable
ALTER TABLE `Interactions` MODIFY `deletedDate` DATETIME(3) NULL;
