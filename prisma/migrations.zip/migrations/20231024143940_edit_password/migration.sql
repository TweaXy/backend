-- AlterTable
ALTER TABLE `User` MODIFY `password` VARCHAR(250) NOT NULL;
