-- AlterTable
ALTER TABLE `User` MODIFY `phone` VARCHAR(11) NULL,
    MODIFY `birthdayDate` DATE NULL;
